import * as LogFactory from 'bunyan'

const log = LogFactory.createLogger({name: 'BitDAO.Token.Contract'})

export {log}
